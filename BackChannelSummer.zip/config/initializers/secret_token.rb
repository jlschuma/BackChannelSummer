# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BackChannelSummer::Application.config.secret_token = '60b0d4b1c554d90d9021213e2582685b37d5df7781d431deede634afcbfd0a9e5d233f1d97fa037216506fefb6e5e2a1cfa6e2c156c45971e3b52dd35710faca'
